import UIKit
import Capacitor
import AVFAudio
import Darwin

class JollyBridgeViewController: CAPBridgeViewController {
    override func capacitorDidLoad() {
        bridge?.registerPluginInstance(JollyNativePlugin())
    }
}

@objc(JollyNativePlugin)
public class JollyNativePlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "JollyNativePlugin"
    public let jsName = "JollyNative"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "clock", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "prepareAudio", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "playCatch", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopAudio", returnType: CAPPluginReturnPromise)
    ]
    private var serverAnchor: Double?
    private var elapsed: () -> Double = { 0 }
    private var players: [AVAudioPlayer] = []
    private var sounds: [String: Data] = [:]
    private var fixedZone: String {
        let key = "jollybox.fixedTimezone.v1"
        if let saved = UserDefaults.standard.string(forKey: key), TimeZone(identifier: saved) != nil { return saved }
        let zone = TimeZone.current.identifier
        UserDefaults.standard.set(zone, forKey: key)
        return zone
    }
    private func replyClock(_ call: CAPPluginCall) {
        var result: [String: Any] = ["zone": fixedZone, "verified": false]
        if let anchor = serverAnchor {
            result["verified"] = true
            result["utc"] = anchor + max(0, elapsed()) * 1000
        } else {
            result["lastVerifiedUTC"] = UserDefaults.standard.double(forKey: "jollybox.verifiedUTC.v1")
        }
        call.resolve(result)
    }
    @objc func clock(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            _ = self.fixedZone
            if self.serverAnchor != nil && !(call.getBool("refresh") ?? false) { self.replyClock(call); return }
            let origin = self.getConfig().getString("timeOrigin") ?? "https://bluffle.co.uk/"
            guard var url = URLComponents(string: origin), url.scheme == "https", let host = url.host else {
                call.reject("Trusted time needs a configured HTTPS origin."); return
            }
            url.queryItems = [URLQueryItem(name: "jollybox-clock", value: UUID().uuidString)]
            guard let endpoint = url.url else { call.reject("Invalid time origin."); return }
            var request = URLRequest(url: endpoint, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 8)
            request.httpMethod = "HEAD"
            request.setValue("no-cache, no-store", forHTTPHeaderField: "Cache-Control")
            let configuration = URLSessionConfiguration.ephemeral
            configuration.urlCache = nil
            configuration.httpCookieStorage = nil
            let session = URLSession(configuration: configuration)
            session.dataTask(with: request) { _, response, error in
                session.finishTasksAndInvalidate()
                let http = response as? HTTPURLResponse
                let formatter = DateFormatter()
                formatter.locale = Locale(identifier: "en_US_POSIX")
                formatter.timeZone = TimeZone(secondsFromGMT: 0)
                formatter.dateFormat = "EEE',' dd MMM yyyy HH':'mm':'ss z"
                let date = http?.value(forHTTPHeaderField: "Date").flatMap { formatter.date(from: $0) }
                let age = Double(http?.value(forHTTPHeaderField: "Age") ?? "0") ?? -1
                let finalHost = http?.url?.host?.replacingOccurrences(of: "www.", with: "")
                let expectedHost = host.replacingOccurrences(of: "www.", with: "")
                let valid = error == nil && http != nil && (200..<400).contains(http!.statusCode)
                    && http?.url?.scheme == "https" && finalHost == expectedHost
                    && http?.value(forHTTPHeaderField: "X-Page-Type") != "blocked"
                    && date != nil && age >= 0 && age <= 3600
                DispatchQueue.main.async {
                    if valid, let date = date {
                        let value = (date.timeIntervalSince1970 + age) * 1000
                        let prior = UserDefaults.standard.double(forKey: "jollybox.verifiedUTC.v1")
                        if value >= prior - 120000 && value > 1262304000000 && value < 4102444800000 {
                            self.serverAnchor = max(value, prior)
                            // Continuous monotonic time includes sleep and ignores date settings.
                            let start = clock_gettime_nsec_np(CLOCK_MONOTONIC_RAW)
                            self.elapsed = {
                                Double(clock_gettime_nsec_np(CLOCK_MONOTONIC_RAW) - start) / 1e9
                            }
                            UserDefaults.standard.set(self.serverAnchor!, forKey: "jollybox.verifiedUTC.v1")
                        }
                    }
                    self.replyClock(call)
                }
            }.resume()
        }
    }
    private func preparePlayback() throws {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers])
        try AVAudioSession.sharedInstance().setActive(true)
    }
    @objc func prepareAudio(_ call: CAPPluginCall) {
        DispatchQueue.main.async { do { try self.preparePlayback(); call.resolve(["ready": true]) }
            catch { call.reject("Audio could not start.", nil, error) } }
    }
    @objc func stopAudio(_ call: CAPPluginCall) {
        DispatchQueue.main.async { self.players.forEach { $0.stop() }; self.players.removeAll(); call.resolve() }
    }
    @objc func playCatch(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            if call.getBool("enabled") == false { call.resolve(["played": false]); return }
            do {
                try self.preparePlayback()
                let melody = [76,76,76,76,76,76,76,79,72,74,76,77,77,77,77,77,76,76,76,76,74,74,76,74,79]
                let good = call.getBool("good") ?? true
                let index = max(0, call.getInt("index") ?? 0) % melody.count
                let midi = melody[index]
                let key = good ? "note-\(midi)" : "miss"
                if self.sounds[key] == nil { self.sounds[key] = self.wave(midi: midi, good: good) }
                if !good { self.players.forEach { $0.stop() } }
                self.players = self.players.filter { $0.isPlaying }
                let player = try AVAudioPlayer(data: self.sounds[key]!)
                player.volume = 0.9
                player.prepareToPlay()
                self.players.append(player)
                guard player.play() else { call.reject("The catch sound could not play."); return }
                call.resolve(["played": true, "midi": midi, "backend": "native"])
            } catch { call.reject("The catch sound could not play.", nil, error) }
        }
    }
    private func wave(midi: Int, good: Bool) -> Data {
        let rate = 22050, duration = good ? 0.34 : 0.48
        let count = Int(Double(rate) * duration)
        var data = Data()
        func text(_ s: String) { data.append(contentsOf: s.utf8) }
        func word(_ x: UInt16) { var v = x.littleEndian; withUnsafeBytes(of: &v) { data.append(contentsOf: $0) } }
        func long(_ x: UInt32) { var v = x.littleEndian; withUnsafeBytes(of: &v) { data.append(contentsOf: $0) } }
        text("RIFF"); long(UInt32(36 + count * 2)); text("WAVEfmt "); long(16); word(1); word(1)
        long(UInt32(rate)); long(UInt32(rate * 2)); word(2); word(16); text("data"); long(UInt32(count * 2))
        for i in 0..<count {
            let t = Double(i) / Double(rate)
            let local = good ? t : t.truncatingRemainder(dividingBy: 0.16)
            let frequency = good ? 440 * pow(2, Double(midi - 69) / 12) : [196.0,147.0,98.0][min(2,Int(t / 0.16))]
            let phase = 2 * Double.pi * frequency * t
            let envelope = min(1,local / 0.008) * exp(-local * (good ? 11 : 18)) * max(0,1-t/duration)
            let value = (sin(phase) + 0.14 * sin(phase * 2) + 0.04 * sin(phase * 3)) * envelope * 0.38
            word(UInt16(bitPattern: Int16(max(-32767,min(32767,Int(value * 32767))))))
        }
        return data
    }
}

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }
        window = UIWindow(windowScene: windowScene)
        window?.rootViewController = JollyBridgeViewController()
        window?.makeKeyAndVisible()
        SceneDelegateProxy.shared.scene(scene, willConnectTo: session, options: connectionOptions)
    }
    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        SceneDelegateProxy.shared.scene(scene, openURLContexts: URLContexts)
    }
    func scene(_ scene: UIScene, continue userActivity: NSUserActivity) {
        SceneDelegateProxy.shared.scene(scene, continue: userActivity)
    }
}
