/* Disclosed App Review access. Session-only demonstration data, never date overrides. */
let appReviewSnapshot=null;
globalThis.jollyAppReviewActive=false;
const reviewSaveFamilyBefore=saveFamily;
saveFamily=function(){if(!globalThis.jollyAppReviewActive)return reviewSaveFamilyBefore()};
function clearAppReviewSamples(){previewHatched.clear();previewMissionDone.clear();previewCare.clear();secretPreviewStates.clear();previewDoorVisits.clear();cardCapersSeen.clear()}
function leaveAppReview(){
 if(!appReviewSnapshot)return;
 dispose();dispose=()=>{};modal.close();
 state.children=appReviewSnapshot.children;state.activeChildId=appReviewSnapshot.activeChildId;state.sound=appReviewSnapshot.sound;
 appReviewSnapshot=null;globalThis.jollyAppReviewActive=false;preview=false;exploring=false;previewState={};offlineVillage=false;
 clearAppReviewSamples();applyChildPlan();view='calendar';jollyWelcome=true;render();
}
function enterAppReview(){
 if(globalThis.jollyAppReviewActive)return;
 dispose();dispose=()=>{};modal.close();
 appReviewSnapshot={children:state.children,activeChildId:state.activeChildId,sound:state.sound};
 globalThis.jollyAppReviewActive=true;
 const demo=JSON.parse(JSON.stringify(activeChild()));demo.id='app-review-demo';demo.name='App Review';
 demo.years={};demo.hatched={};demo.care={};demo.records={};demo.missionDone={};demo.voiceMystery={};demo.theatre={};
 state.children=[demo];state.activeChildId=demo.id;
 clearAppReviewSamples();globalThis.jollyDateTesting=false;developmentClockOffset=0;offlineVillage=false;applyChildPlan();jollyWelcome=false;exploreEverything();
}
function appReviewAccess(){
 showModal('<section class="app-review-access"><div class="eyebrow">FOR THE GROWN-UPS</div><h2>App Review access</h2><p class="small-note">For Apple’s review team: enter the access code supplied in the App Review Notes to explore all 24 days using temporary demonstration progress.</p><form id="app-review-form"><label for="app-review-code">Review access code</label><input id="app-review-code" type="password" inputmode="numeric" pattern="[0-9]{6}" minlength="6" maxlength="6" autocomplete="off" required><p class="small-note" id="app-review-error" role="status"></p><button class="btn" type="submit">Start App Review</button></form><p class="small-note">The normal calendar stays date-locked. Demonstration progress is discarded when you leave or restart the app.</p></section>');
 content.querySelector('form').onsubmit=e=>{e.preventDefault();if(content.querySelector('input').value!=='773011'){content.querySelector('#app-review-error').textContent='That code doesn’t match. Please try again.';return}enterAppReview()};
}
function removeDevelopmentControls(){
 document.querySelectorAll('.development-entry,#testing-badge,#date-testing-label,.welcome-preview-wait').forEach(e=>e.remove());
}
// Public access to the former test unlock is replaced by the disclosed code entry.
const reviewExploreBefore=exploreEverything;
exploreEverything=function(){if(!globalThis.jollyAppReviewActive)return appReviewAccess();return reviewExploreBefore()};
developmentTools=appReviewAccess;
setCalendarTest=function(){toast('Date simulation is unavailable in this build.')};
const reviewAccessWelcomeBefore=renderJollyWelcome;
renderJollyWelcome=function(){reviewAccessWelcomeBefore();removeDevelopmentControls();const host=main.querySelector('#jolly-production-opening');if(!host)return;const b=document.createElement('button');b.className='app-review-entry';b.textContent='Grown-ups';b.onclick=appReviewAccess;host.appendChild(b)};
const reviewAccessStationBefore=powerStation;
powerStation=function(){reviewAccessStationBefore();content.querySelectorAll('button').forEach(b=>{if(/Development:|dates and unlocks|testing/i.test(b.textContent))b.remove()});if(globalThis.jollyAppReviewActive){content.querySelector('#station-child')?.remove();const b=content.querySelector('#station-preview');if(b){b.textContent='Leave App Review';b.onclick=leaveAppReview}}else{content.querySelector('#station-preview')?.remove();const b=document.createElement('button');b.className='btn secondary';b.textContent='App Review access';b.onclick=appReviewAccess;content.appendChild(b)}};
const reviewAccessRenderBefore=render;
render=function(){reviewAccessRenderBefore();removeDevelopmentControls();document.querySelector('.app-review-banner')?.remove();if(!globalThis.jollyAppReviewActive)return;const banner=document.createElement('div');banner.className='app-review-banner';banner.innerHTML='<span>App Review · all 24 days</span><button type="button">Leave review</button>';banner.querySelector('button').onclick=leaveAppReview;document.body.appendChild(banner)};
