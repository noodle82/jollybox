/* Matched fur artwork follows the existing shoulder/elbow/hand rig. The same
   fine, illustrated hair and lighting are used across head, chest and paws. */
const COMPANION_BODY_ART={cloud:'assets/cloud-matched-body.webp',dragon:'assets/dragon-matched-body.webp',deer:'assets/deer-matched-body.webp'};
const companionBodyImages=new Map();
function companionBodyImage(species){if(!companionBodyImages.has(species))companionBodyImages.set(species,new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=reject;im.src=COMPANION_BODY_ART[species]}));return companionBodyImages.get(species)}
class MatchedCompanionBody{
 constructor(rig){this.rig=rig;this.ready=false;this.parts=[];rig.canvas.dataset.bodyArt='loading';companionBodyImage(rig.species).then(image=>{if(rig.closed)return;this.build(image);this.ready=true;rig.canvas.dataset.bodyArt='matched-fur';if(rig.lastPortraitPose)rig.animate(rig.lastPortraitPose)}).catch(()=>{if(!rig.closed)rig.canvas.dataset.bodyArt='fallback'})}
 build(image){const r=this.rig,T=r.T;this.texture=new T.Texture(image);this.texture.colorSpace=T.SRGBColorSpace;this.texture.needsUpdate=true;this.material=new T.MeshBasicMaterial({map:this.texture,transparent:true,depthWrite:false,alphaTest:.025,side:T.DoubleSide,toneMapped:false});
  // Three 512px cells: seated torso and feet, left arm, right arm. Every cell
  // retains its transparent fur fringe and has the same padded square framing.
  const make=(cell,segments=1)=>{const g=new T.PlaneGeometry(1,1,6,segments),uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setX(i,(uv.getX(i)+cell)/3);const m=new T.Mesh(g,this.material);m.frustumCulled=false;r.root.add(m);this.parts.push(m);return m};
  this.body=make(0,12);this.body.position.set(0,.55,.38);this.body.scale.set(2.05,2.05,1);
  this.arms=[make(1,28),make(2,28)];for(const m of this.arms){m.material=this.material.clone();m.material.depthTest=false;m.renderOrder=10;}for(const prop of Object.values(r.props))prop.traverse(o=>{if(o.isMesh){o.material=o.material.clone();o.material.transparent=true;o.material.depthTest=false;o.renderOrder=20;}});
  r.portrait.mesh.renderOrder=8;r.clothes.scale.set(1.32,1.08,1.03);for(const garment of[r.clothes,...r.garmentParts])garment.traverse(o=>{if(o.isMesh){o.material=o.material.clone();o.material.transparent=true;o.material.depthTest=false;o.renderOrder=4;}});this.skin=[];for(const a of r.arms){for(const group of[a.upper,a.fore])for(const o of group.children)if(o.isLineSegments||o.isMesh&&o.material===r.fur)this.skin.push(o);for(const o of a.hand.children)if(!Object.values(r.props).includes(o))this.skin.push(o)}
 }
 update(options){if(!this.ready)return;const r=this.rig,T=r.T;for(const o of[r.body,r.chest,...r.feet,...this.skin])o.visible=false;if(r.tail)r.tail.visible=false;if(r.wings)for(const w of r.wings)w.visible=false;
  this.body.scale.y=2.05*(1+Math.sin(options.time*2.2)*.004);this.body.rotation.z=Math.sin(options.time*.8)*.003;
  for(let i=0;i<2;i++){const a=r.arms[i],mesh=this.arms[i],p=mesh.geometry.attributes.position,uv=mesh.geometry.attributes.uv;
   const s=a.shoulder.clone(),solvedShoulder=s.clone(),h=a.hand.position.clone();if(options.action?.type==='brush'&&i)solvedShoulder.y+=.32;const elbow=a.upper.position.clone().multiplyScalar(2).sub(solvedShoulder);
   // Keep a soft paw at the actual hand anchor. Furred arm is a curved ribbon
   // through the solved elbow, rather than rotating disconnected cylinders.
   const start=s.clone().lerp(elbow,.05),end=h.clone().add(new T.Vector3(0,-.055,.09));
   for(let k=0;k<p.count;k++){const v=1-uv.getY(k),x=(uv.getX(k)*3-(i+1))-.5;
    // Art has padding around its upper shoulder and paw. Those painted points
    // are mapped to the arm endpoints, preserving the original furry outline.
    const t=(v-.11)/.78,u=1-t,aa=u*u,bb=2*u*t,cc=t*t,dx=2*u*(elbow.x-start.x)+2*t*(end.x-elbow.x),dy=2*u*(elbow.y-start.y)+2*t*(end.y-elbow.y),length=Math.max(.001,Math.hypot(dx,dy)),offset=x*.85;
    p.setXYZ(k,start.x*aa+elbow.x*bb+end.x*cc-dy/length*offset,start.y*aa+elbow.y*bb+end.y*cc+dx/length*offset,start.z*aa+elbow.z*bb+end.z*cc+.08);
   }p.needsUpdate=true;
  }
  r.canvas.dataset.furMatch='continuous-matched-art';r.canvas.dataset.bodyAnimation='joint-following-fur';
 }
 close(){for(const m of this.parts){m.geometry.dispose();if(m.material!==this.material)m.material.dispose();m.removeFromParent()}this.material?.dispose();this.texture?.dispose()}
}
const HeadMatchedCompanionBase=LittleCompanionRig;
LittleCompanionRig=class extends HeadMatchedCompanionBase{
 constructor(...args){super(...args);this.matchedBody=new MatchedCompanionBody(this)}
 animate(options){if(!this.matchedBody)return super.animate(options);const draw=this.studio.render;this.studio.render=()=>{};try{super.animate(options);this.matchedBody.update(options)}finally{this.studio.render=draw}draw()}
 close(){this.matchedBody?.close();super.close()}
};
